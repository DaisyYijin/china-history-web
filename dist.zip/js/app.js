/* =========================================================
 * 中国通史 · 页面逻辑
 * 包含：主题切换 / 标签页 / 时期折叠 / 人物分页 /
 *       两点关系查询（含间接关系搜索）/ 弹窗 / 力导向图谱
 * ========================================================= */

/* ---------- 常量 ---------- */
const CATS = {
  war:      { name: "战争 · 战役", color: "#e05c4b" },
  civil:    { name: "革命 · 起义", color: "#e0994a" },
  reform:   { name: "变革 · 运动", color: "#4fae9b" },
  politics: { name: "政治 · 会议", color: "#5f8ec9" },
  culture:  { name: "文明 · 科技", color: "#a879d8" }
};

const PERIODS = {
  1:  { name: "传说时代",         sub: "远古 — 约前2070 · 炎黄肇始" },
  2:  { name: "夏商西周",         sub: "约前2070 — 前771 · 青铜文明" },
  3:  { name: "春秋战国",         sub: "前770 — 前221 · 百家争鸣" },
  4:  { name: "秦汉",             sub: "前221 — 220 · 大一统奠基" },
  5:  { name: "三国两晋南北朝",   sub: "220 — 589 · 分裂与融合" },
  6:  { name: "隋唐五代",         sub: "581 — 960 · 盛世气象" },
  7:  { name: "宋辽金夏",         sub: "960 — 1279 · 文华鼎盛" },
  8:  { name: "元朝",             sub: "1271 — 1368 · 草原帝国" },
  9:  { name: "明朝",             sub: "1368 — 1644 · 治隆唐宋" },
  10: { name: "清朝前中期",       sub: "1644 — 1840 · 最后的帝国" },
  11: { name: "晚清",             sub: "1840 — 1911 · 内忧外患" },
  12: { name: "民国初年",         sub: "1912 — 1926 · 共和乱局" },
  13: { name: "国共对峙",         sub: "1927 — 1936 · 星火燎原（含局部抗战）" },
  14: { name: "全面抗战",         sub: "1937 — 1945 · 民族浴血" },
  15: { name: "解放战争",         sub: "1946 — 1949 · 天翻地覆" },
  16: { name: "当代中国",         sub: "1949 — 今 · 复兴之路" }
};

const TABS = ["timeline-section", "graph-section", "people-section", "map-section"];
const PAGE_SIZE = 60;
const THEME_KEY = "history-theme";

/* ---------- 工具 ---------- */
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}
/* 术语自动注释：正文中的词典词条加标记，点击弹大白话解释 */
let glossaryRegex = null;
function glossarize(escapedText) {
  if (typeof GLOSSARY === "undefined" || !escapedText) return escapedText;
  try {
    if (!glossaryRegex) {
      // 词典键均为中文词，无需正则转义；长词优先避免短词截断匹配
      const keys = Object.keys(GLOSSARY).sort((a, b) => b.length - a.length);
      glossaryRegex = new RegExp(keys.join("|"), "g");
    }
    return escapedText.replace(glossaryRegex, m =>
      `<span class="term" data-term="${m}">${m}</span>`);
  } catch (e) { return escapedText; }
}

function showTermPop(el) {
  hideTermPop();
  const tip = document.createElement("div");
  tip.className = "term-pop";
  tip.innerHTML = `<b>${esc(el.dataset.term)}</b><br>${esc(GLOSSARY[el.dataset.term] || "")}`;
  document.body.appendChild(tip);
  const r = el.getBoundingClientRect();
  const w = Math.min(340, window.innerWidth - 24);
  tip.style.width = w + "px";
  let x = r.left + r.width / 2 - w / 2;
  x = Math.max(12, Math.min(x, window.innerWidth - w - 12));
  let y = r.bottom + 8;
  if (y + 140 > window.innerHeight) y = r.top - tip.offsetHeight - 8;
  tip.style.left = x + "px";
  tip.style.top = y + "px";
  tip.addEventListener("click", hideTermPop);
  setTimeout(() => document.addEventListener("click", hideTermPop, { once: true }), 0);
}
function hideTermPop() {
  document.querySelectorAll(".term-pop").forEach(e => e.remove());
}

function cssVar(name) {
  return getComputedStyle(document.body).getPropertyValue(name).trim();
}

/* ---------- 索引 ---------- */
const EVENT_MAP = {};
EVENTS.forEach((e, i) => { EVENT_MAP[e.id] = e; e._order = i; });

const PEOPLE_LIST = Object.keys(PEOPLE).map(id => Object.assign({ id }, PEOPLE[id]));
const PERSON_MAP = {};
PEOPLE_LIST.forEach(p => { PERSON_MAP[p.id] = p; });

const DEGREE = {};
const ADJ = {};
RELATIONS.forEach(r => {
  DEGREE[r.a] = (DEGREE[r.a] || 0) + 1;
  DEGREE[r.b] = (DEGREE[r.b] || 0) + 1;
  (ADJ[r.a] = ADJ[r.a] || []).push({ to: r.b, t: r.t });
  (ADJ[r.b] = ADJ[r.b] || []).push({ to: r.a, t: r.t });
});

function periodOf(ev) {
  if (ev.p) return ev.p;
  if (ev.year <= 1911) return 11;
  if (ev.year <= 1926) return 12;
  if (ev.year <= 1936) return 13;
  if (ev.year <= 1945) return 14;
  if (ev.year <= 1949) return 15;
  return 16;
}

/* ---------- 主题切换 ---------- */
function currentTheme() {
  try { return localStorage.getItem(THEME_KEY) || "dark"; } catch (e) { return "dark"; }
}
function applyTheme(t, rebuild) {
  document.body.classList.toggle("light", t === "light");
  const btn = document.getElementById("theme-toggle");
  if (btn) btn.textContent = t === "light" ? "☀️" : "🌙";
  if (rebuild) {
    if (mainChart) applyGraphFilter();
    if (miniPersonId) renderMiniGraph(miniPersonId, FACTIONS[PERSON_MAP[miniPersonId].faction].color);
  }
}
document.getElementById("theme-toggle").onclick = () => {
  const t = currentTheme() === "light" ? "dark" : "light";
  try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
  applyTheme(t, true);
};

/* ---------- 标签页 ---------- */
function switchTab(id, push) {
  TABS.forEach(s => {
    const el = document.getElementById(s);
    if (el) el.classList.toggle("tab-active", s === id);
  });
  document.querySelectorAll(".tab-link, .side-link").forEach(a =>
    a.classList.toggle("active", a.dataset.tabLink === id));
  if (id === "graph-section") {
    if (!mainChart) initGraph();
    else if (mainChart) mainChart.resize();
  }
  if (id === "map-section") {
    // 延迟到脚本全部执行完（加载期 hash 直达此 tab 时，模块底部的声明尚未初始化）
    setTimeout(() => {
      if (!periodMapChart) initPeriodMap();
      else periodMapChart.resize();
    }, 0);
  }
  if (push !== false) try { history.replaceState(null, "", "#" + id); } catch (e) {}
  window.scrollTo({ top: 0, behavior: "instant" });
}
document.addEventListener("click", e => {
  const l = e.target.closest("[data-tab-link]");
  if (l) { e.preventDefault(); switchTab(l.dataset.tabLink); }
});

/* ---------- 顶部统计 ---------- */
(function renderStats() {
  const items = [
    [EVENTS.length, "重大事件"],
    [PEOPLE_LIST.length, "关键人物"],
    [RELATIONS.length, "人物关系"],
    ["5000", "年文明史"]
  ];
  document.getElementById("stats").innerHTML = items.map(([n, label]) =>
    `<div class="stat"><b>${n}</b><span>${label}</span></div>`).join("");
})();

/* ---------- 大事年表 ---------- */
let catFilter = "all";
const openEras = new Set();

function renderCatFilters() {
  const box = document.getElementById("cat-filters");
  const defs = [["all", null]].concat(Object.keys(CATS).map(k => [k, CATS[k]]));
  box.innerHTML = defs.map(([key, c]) =>
    `<button class="filter-btn ${key === catFilter ? "active" : ""}" data-cat="${key}">
      ${c ? `<span class="dot" style="background:${c.color}"></span>${c.name}` : "全部事件"}
     </button>`).join("");
  box.querySelectorAll(".filter-btn").forEach(btn => {
    btn.onclick = () => { catFilter = btn.dataset.cat; renderCatFilters(); renderTimeline(); };
  });
}

function renderTimeline() {
  const wrap = document.getElementById("timeline");
  const term = getTerm();
  const byPeriod = {};
  EVENTS.forEach(ev => {
    const p = periodOf(ev);
    (byPeriod[p] = byPeriod[p] || []).push(ev);
  });

  if (openEras.size === 0) {
    // 默认展开全部时期：确保首次访问者能看到所有事件
    Object.keys(byPeriod).forEach(pk => openEras.add(pk));
  }

  let html = "";
  Object.keys(PERIODS).forEach(pk => {
    const list = (byPeriod[pk] || []).sort((x, y) => x.year - y.year || x._order - y._order);
    if (!list.length) return;
    const shown = list.filter(ev =>
      (catFilter === "all" || ev.category === catFilter) &&
      (!term || evMatch(ev, term)));
    if (!shown.length) return;   // 该时期无匹配事件时整个时期不显示
    html += `<div class="era ${openEras.has(pk) ? "open" : ""}" data-era="${pk}">
      <div class="era-head">
        <div class="era-line"></div>
        <span>${PERIODS[pk].name}<em>${PERIODS[pk].sub}</em></span>
        <span class="era-meta">${shown.length} 事<i class="era-toggle">▾</i></span>
      </div>
      <div class="era-body"><div class="timeline">`;
    list.forEach(ev => {
      const cat = CATS[ev.category];
      const matched = (catFilter === "all" || ev.category === catFilter) &&
        (!term || evMatch(ev, term));
      const forceLine = ev.forces ? `<div class="force-line">${ev.forces.map(f =>
        `<b>${esc(f.side)}</b>：${esc(f.troops)}`).join(" ｜ ")}</div>` : "";
      html += `<div class="t-item ${matched ? "" : "hidden-by-filter"}" data-ev="${ev.id}">
        <span class="dot" style="background:${cat.color}"></span>
        <div class="t-card" data-open-event="${ev.id}">
          <div class="t-top">
            <span class="t-year">${ev.year < 0 ? "前" + (-ev.year) : ev.year}</span>
            <span class="t-title">${esc(ev.title)}</span>
            <span class="t-tag" style="color:${cat.color}">${cat.name}</span>
          </div>
          <div class="t-date">${esc(ev.date)}</div>
          <div class="t-snippet">${esc(ev.desc.slice(0, 64))}…</div>
          ${forceLine}
          <div class="t-people">关键人物：<i>${ev.people.map(id => esc(PERSON_MAP[id] ? PERSON_MAP[id].name : id)).join("、") || "—"}</i></div>
          <span class="t-more">查看详情 ›</span>
      </div>`;
    });
    html += `</div></div></div>`;
  });
  wrap.innerHTML = html;
  wrap.classList.toggle("searching", !!term || catFilter !== "all");
  syncToggleAllBtn();
}

function evMatch(ev, term) {
  const hay = [ev.title, ev.date, ev.desc, ev.result || "", ev.people.map(id => PERSON_MAP[id] && PERSON_MAP[id].name).join("、")].join("\n");
  return hay.indexOf(term) !== -1;
}

document.getElementById("timeline").addEventListener("click", e => {
  const head = e.target.closest(".era-head");
  if (head) {
    const era = head.parentElement;
    era.classList.toggle("open");
    if (era.classList.contains("open")) openEras.add(era.dataset.era);
    else openEras.delete(era.dataset.era);
    syncToggleAllBtn();
  }
});

const eraToggleAllBtn = document.getElementById("era-toggle-all");
eraToggleAllBtn.onclick = () => {
  const eras = [...document.querySelectorAll("#timeline .era")];
  const anyClosed = eras.some(el => !el.classList.contains("open"));
  eras.forEach(el => {
    el.classList.toggle("open", anyClosed);
    if (anyClosed) openEras.add(el.dataset.era); else openEras.delete(el.dataset.era);
  });
  syncToggleAllBtn();
};
function syncToggleAllBtn() {
  const eras = [...document.querySelectorAll("#timeline .era")];
  const allOpen = eras.length > 0 && eras.every(el => el.classList.contains("open"));
  eraToggleAllBtn.textContent = allOpen ? "收起全部" : "展开全部";
}

/* ---------- 人物志 ---------- */
let factionFilter = "all";
let peoplePage = 1;

function renderFactionFilters() {
  const box = document.getElementById("faction-filters");
  const defs = [["all", { name: "全部人物", color: "#d3a94f" }]]
    .concat(Object.keys(FACTIONS).map(k => [k, FACTIONS[k]]));
  box.innerHTML = defs.map(([key, f]) =>
    `<button class="filter-btn ${key === factionFilter ? "active" : ""}" data-f="${key}">
      <span class="dot" style="background:${f.color}"></span>${f.name}
     </button>`).join("");
  box.querySelectorAll(".filter-btn").forEach(btn => {
    btn.onclick = () => { factionFilter = btn.dataset.f; peoplePage = 1; renderFactionFilters(); renderPeopleGrid(); };
  });
}

function renderPeopleGrid() {
  const grid = document.getElementById("people-grid");
  const term = getTerm();
  const list = PEOPLE_LIST.filter(p =>
    (factionFilter === "all" || p.faction === factionFilter) &&
    (!term || personMatch(p, term)));
  const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  if (peoplePage > pages) peoplePage = pages;
  const slice = list.slice((peoplePage - 1) * PAGE_SIZE, peoplePage * PAGE_SIZE);

  grid.innerHTML = slice.length ? slice.map(p => {
    const f = FACTIONS[p.faction];
    return `<div class="p-card" data-open-person="${p.id}" title="${esc(p.title)}">
      <div class="avatar" style="color:${f.color};border-color:${f.color}">${esc(p.name[0])}</div>
      <div class="p-name">${esc(p.name)}</div>
      <div class="p-life">${esc(p.life)}</div>
      <div class="p-title">${esc(p.title)}</div>
      <span class="p-faction" style="color:${f.color};border-color:${f.color}">${f.name}</span>
    </div>`;
  }).join("") : `<div class="grid-empty">没有匹配的人物</div>`;

  const pager = document.getElementById("people-pagination");
  if (pages <= 1) { pager.innerHTML = ""; return; }
  pager.innerHTML = `
    <button class="mini-btn" data-page="prev" ${peoplePage <= 1 ? "disabled" : ""}>上一页</button>
    <span class="page-info">第 ${peoplePage} / ${pages} 页 · 共 ${list.length} 人</span>
    <button class="mini-btn" data-page="next" ${peoplePage >= pages ? "disabled" : ""}>下一页</button>`;
}
document.getElementById("people-pagination").addEventListener("click", e => {
  const btn = e.target.closest("[data-page]");
  if (!btn || btn.disabled) return;
  peoplePage += btn.dataset.page === "next" ? 1 : -1;
  renderPeopleGrid();
  document.getElementById("people-section").scrollIntoView({ behavior: "instant", block: "start" });
});

function personMatch(p, term) {
  const f = FACTIONS[p.faction];
  const evNames = (p.events || []).map(id => EVENT_MAP[id] && EVENT_MAP[id].title).join("、");
  return [p.name, p.title, p.life, p.bio, f.name, evNames].join("\n").indexOf(term) !== -1;
}

/* ---------- 搜索 ---------- */
function getTerm() {
  const v = document.getElementById("search").value.trim();
  return v || "";
}
let searchTimer = null;
document.getElementById("search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    peoplePage = 1;
    renderTimeline();
    renderPeopleGrid();
  }, 150);
});

/* ---------- 弹窗 ---------- */
const modalMask = document.getElementById("modal-mask");
const modalBody = document.getElementById("modal-body");
let miniChart = null;
let miniPersonId = null;

function openModal() {
  modalMask.hidden = false;
  document.body.style.overflow = "hidden";
}
function closeModal() {
  modalMask.hidden = true;
  document.body.style.overflow = "";
  if (miniChart) { miniChart.dispose(); miniChart = null; }
  miniPersonId = null;
}
document.getElementById("modal-close").onclick = closeModal;
modalMask.addEventListener("click", e => { if (e.target === modalMask) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !modalMask.hidden) closeModal(); });

/* ---------- 关系线详情：点击连线 → 相关战役/事件 ---------- */
function sharedEventsOf(aId, bId) {
  const ea = new Set(PEOPLE[aId].events || []);
  return (PEOPLE[bId].events || []).filter(e => ea.has(e));
}

function openRelation(aId, bId, t) {
  const A = PERSON_MAP[aId], B = PERSON_MAP[bId];
  if (!A || !B) return;
  const shared = sharedEventsOf(aId, bId);
  // 恰好共同参与一个事件（多为战役对手）→ 直接打开该事件详情
  if (shared.length === 1) { openEvent(shared[0]); return; }
  const fa = FACTIONS[A.faction], fb = FACTIONS[B.faction];
  const evCards = shared.map(eid => {
    const ev = EVENT_MAP[eid]; if (!ev) return "";
    const c = CATS[ev.category];
    return `<div class="rel-ev-card" data-open-event="${eid}">
      <span class="dot" style="background:${c.color}"></span>
      <div class="rel-ev-info"><b>${esc(ev.title)}</b><span>${ev.year < 0 ? "前" + (-ev.year) : ev.year} · ${esc(ev.date)} · ${c.name}</span></div>
      <i>查看详情 ›</i>
    </div>`;
  }).join("");
  modalBody.innerHTML = `
    <div class="rel-head">
      <button class="chip" data-open-person="${aId}"><span class="dot" style="background:${fa.color}"></span>${esc(A.name)}</button>
      <span class="rel-arrow">— ${esc(t)} —</span>
      <button class="chip" data-open-person="${bId}"><span class="dot" style="background:${fb.color}"></span>${esc(B.name)}</button>
    </div>
    ${shared.length
      ? `<h4 class="m-h4">共同参与的事件（点击查看详情）</h4><div class="rel-ev-list">${evCards}</div>`
      : `<div class="result-box">两人以“${esc(t)}”相连——这一关系源于生平交集（详见双方详情），未共同参与收录的战役或事件。</div>`}
    <div class="chips" style="margin-top:14px">
      <button class="chip" data-open-person="${aId}">查看 ${esc(A.name)} 详情</button>
      <button class="chip" data-open-person="${bId}">查看 ${esc(B.name)} 详情</button>
    </div>`;
  openModal();
  modalBody.scrollTop = 0;
}

function openEvent(id) {
  const ev = EVENT_MAP[id];
  if (!ev) return;
  const cat = CATS[ev.category];
  const period = PERIODS[periodOf(ev)];

  const catNote = {
    war: "这是一场战争或战役，下方列出交战双方投入的兵力对比。",
    civil: "这是一次起义或革命，下方列出对抗双方的规模。",
    reform: "这是一次改革或思想文化运动，通常没有两军对垒，故无兵力数据。",
    politics: "这是一次政治事件或重要会议，没有两军对垒，故无兵力数据。",
    culture: "这是一项文明成就或科技发明，与战争无关，故无兵力数据。"
  };
  const adversarial = ev.category === "war" || ev.category === "civil";
  const forcesHtml = ev.forces
    ? `<h4 class="m-h4">${adversarial ? "对峙双方兵力" : "参与各方规模"}</h4>
       <div class="beginner-note">${adversarial
          ? catNote[ev.category]
          : "这不是战争对抗——下表列出的是参与此事件的各方人员或规模，帮助你了解它的分量。"}</div>
       <div class="vs">
      <div class="side"><div class="s-name" style="color:#e0846f">${esc(ev.forces[0].side)}</div>
        <div class="s-troops">${esc(ev.forces[0].troops)}</div></div>
      <div class="vs-badge">${adversarial ? "对<small>峙</small>" : "参<small>与</small>"}</div>
      <div class="side"><div class="s-name" style="color:#7fa8dd">${esc(ev.forces[1].side)}</div>
        <div class="s-troops">${esc(ev.forces[1].troops)}</div></div>
    </div>`
    : `<h4 class="m-h4">事件性质</h4>
       <div class="beginner-note">${catNote[ev.category] || catNote.politics}</div>`;

  const peopleHtml = `<h4 class="m-h4">关键人物（点击名字可查看生平）</h4><div class="chips">${
    ev.people.length ? ev.people.map(pid => {
      const p = PERSON_MAP[pid]; if (!p) return "";
      const f = FACTIONS[p.faction];
      return `<button class="chip" data-open-person="${pid}">
        <span class="dot" style="background:${f.color}"></span>${esc(p.name)}<em style="color:${f.color}">${f.name}</em>
      </button>`;
    }).join("") : `<span style="color:var(--muted);font-size:13.5px">民众自发参与，无明确个体人物记载</span>`
  }</div>`;

  const plain = typeof EVENT_PLAIN !== "undefined" && EVENT_PLAIN[ev.id];
  modalBody.innerHTML = `
    <span class="m-cat" style="color:${cat.color}">${cat.name}</span><span class="m-date">${esc(ev.date)} · ${period.name}</span>
    <h3 class="m-title">${esc(ev.title)}</h3>
    ${plain ? `<div class="plain-box"><b>🔎 一句话看懂</b><div>${esc(plain)}</div></div>` : ""}
    <h4 class="m-h4">背景与经过</h4>
    <p class="m-desc">${glossarize(esc(ev.desc))}</p>
    ${forcesHtml}
    <h4 class="m-h4">结局与影响</h4>
    <div class="result-box">${glossarize(esc(ev.result))}</div>
    ${peopleHtml}`;
  openModal();
  modalBody.scrollTop = 0;
}

function openPerson(id) {
  const p = PERSON_MAP[id];
  if (!p) return;
  const f = FACTIONS[p.faction];

  const evChips = (p.events || []).map(eid => {
    const ev = EVENT_MAP[eid]; if (!ev) return "";
    const c = CATS[ev.category];
    return `<button class="chip" data-open-event="${eid}">
      <span class="dot" style="background:${c.color}"></span>${esc(ev.title)}</button>`;
  }).join("");

  const relChips = RELATIONS.filter(r => r.a === id || r.b === id).map(r => {
    const otherId = r.a === id ? r.b : r.a;
    const other = PERSON_MAP[otherId]; if (!other) return "";
    const of_ = FACTIONS[other.faction];
    return `<button class="chip chip-rel" data-open-person="${otherId}">
      <span class="dot" style="background:${of_.color}"></span>${esc(other.name)}<em>· ${esc(r.t)}</em></button>`;
  }).join("");

  const tl = typeof PEOPLE_TIMELINE !== "undefined" && PEOPLE_TIMELINE[id];
  const lifeHtml = tl && tl.length ? `<h4 class="m-h4">生平大事记</h4><div class="life-timeline">
    ${tl.map(([y, t]) => `<div class="life-item"><span class="life-year">${esc(y)}</span><span class="life-text">${esc(t)}</span></div>`).join("")}
  </div>` : "";

  const ex = typeof PEOPLE_EXTRA !== "undefined" && PEOPLE_EXTRA[id];
  const quotesHtml = ex && ex.quotes && ex.quotes.length
    ? `<h4 class="m-h4">💬 名言金句</h4><div class="quote-list">
        ${ex.quotes.map(([q, c]) => `<div class="quote-item"><div class="quote-text">「${esc(q)}」</div><div class="quote-ctx">${glossarize(esc(c))}</div></div>`).join("")}
      </div>` : "";
  const worksHtml = ex && ex.works && ex.works.length
    ? `<h4 class="m-h4">📜 代表作品</h4><div class="work-list">
        ${ex.works.map(([t, body, note]) => `<div class="work-box"><div class="work-title">${esc(t)}</div><div class="work-text">${esc(body).replace(/\n/g, "<br>")}</div><div class="work-note">${glossarize(esc(note))}</div></div>`).join("")}
      </div>` : "";
  const assessHtml = ex && ex.assess && ex.assess.length
    ? `<h4 class="m-h4">🏛 后世评价</h4><ul class="assess-list">
        ${ex.assess.map(a => `<li>${glossarize(esc(a))}</li>`).join("")}
      </ul>` : "";

  const wb = typeof WIKI_BIOS !== "undefined" && WIKI_BIOS[id] && WIKI_BIOS[id].extract
    ? WIKI_BIOS[id] : null;
  const wikiSection = wb
    ? `<h4 class="m-h4">📖 扩展阅读 · 维基百科</h4>
       <div class="wiki-box">
         <div class="wiki-text">${glossarize(esc(wb.extract))}</div>
         <div class="wiki-foot">
           <a href="${esc(wb.url)}" target="_blank" rel="noopener">查看完整条目 ↗</a>
           <span>内容来自维基百科，CC BY-SA 4.0 授权</span>
         </div>
       </div>`
    : "";
  const relSection = relChips
    ? `<h4 class="m-h4">人物关系（点击跳转）</h4>
       <div id="mini-graph"></div>
       <div class="chips" style="margin-top:12px">${relChips}</div>`
    : "";
  modalBody.innerHTML = `
    <div class="person-head">
      <div class="avatar" style="color:${f.color};border-color:${f.color}">${esc(p.name[0])}</div>
      <div class="p-meta">
        <h3>${esc(p.name)}</h3>
        <div class="p-life">${esc(p.life)}</div>
        <div class="badges">
          <span class="badge" style="color:${f.color};border-color:${f.color}">${f.name}</span>
          <span class="badge" style="color:var(--gold);border-color:var(--gold)">${esc(p.title)}</span>
        </div>
      </div>
    </div>
    <div class="beginner-note">先认识一下：${esc(p.name)}（${esc(p.life)}），${esc(f.name)}人物 —— ${esc(p.title)}。生词带<span class="term-demo">虚线下划线</span>的都可以点开解释。</div>
    <p class="m-desc">${glossarize(esc(p.bio))}</p>
    ${lifeHtml}
    ${quotesHtml}
    ${worksHtml}
    ${assessHtml}
    <h4 class="m-h4">参与事件</h4>
    <div class="chips">${evChips || '<span style="color:var(--muted);font-size:13.5px">未直接参与收录事件，主要事迹见上方生平</span>'}</div>
    ${relSection}
    ${wikiSection}`;
  openModal();
  modalBody.scrollTop = 0;
  renderMiniGraph(id, f.color);
}

function renderMiniGraph(centerId, color) {
  const el = document.getElementById("mini-graph");
  if (!el || typeof echarts === "undefined") return;
  miniPersonId = centerId;
  const nodes = [{ id: centerId, name: PERSON_MAP[centerId].name, center: true }];
  const seen = { [centerId]: true };
  const links = [];
  RELATIONS.forEach(r => {
    if (r.a === centerId || r.b === centerId) {
      const other = r.a === centerId ? r.b : r.a;
      if (!seen[other]) { seen[other] = true; nodes.push({ id: other, name: PERSON_MAP[other].name }); }
      links.push({ source: r.a, target: r.b, t: r.t });
    }
  });
  // 共点边交替曲率：以中心为端点的连线依次 ±0.05 递增，呈放射扇形
  const miniIdx = {};
  links.forEach(l => {
    const from = l.source === centerId ? l.target : l.source;
    miniIdx[from] = miniIdx[from] || 0;
    l.curve = ((miniIdx[from] % 2 === 0) ? 1 : -1) * (.05 + .05 * Math.floor(miniIdx[from] / 2));
    miniIdx[from]++;
  });
  if (miniChart) { miniChart.dispose(); miniChart = null; }
  miniChart = echarts.init(el);
  miniChart.setOption({
    tooltip: {
      backgroundColor: cssVar("--panel-2") || "rgba(18,21,30,.94)",
      borderColor: "rgba(211,169,79,.5)",
      textStyle: { color: cssVar("--ink") || "#e9e4d6", fontFamily: "serif" },
      formatter(p) {
        if (p.dataType === "edge") return esc(p.data.t);
        return esc(p.name);
      }
    },
    series: [{
      type: "graph", layout: "force", roam: true,
      force: { repulsion: 420, edgeLength: 110, gravity: .12 },
      data: nodes.map(n => ({
        id: n.id, name: n.name,
        symbolSize: n.center ? 52 : 34,
        itemStyle: n.center
          ? { color, borderColor: "#d3a94f", borderWidth: 2, shadowBlur: 16, shadowColor: color }
          : { color: FACTIONS[PERSON_MAP[n.id].faction].color },
        label: {
          show: true, position: "bottom",
          color: n.center ? cssVar("--ink-strong") || "#f0e8d3" : cssVar("--ink-2") || "#c9c2ad",
          fontSize: n.center ? 14 : 12, fontFamily: "serif"
        }
      })),
      links: links.map(l => ({
        source: l.source, target: l.target,
        lineStyle: { color: cssVar("--graph-edge") || "rgba(255,255,255,.25)", width: 1.4, curveness: l.curve || 0 },
        emphasis: { lineStyle: { color: "#d3a94f", width: 2.4 } },
        t: l.t
      })),
      emphasis: { focus: "adjacency" }
    }]
  });
  miniChart.off("click");
  miniChart.on("click", p => {
    if (p.dataType === "node" && p.data.id !== centerId) openPerson(p.data.id);
    else if (p.dataType === "edge") openRelation(p.data.source, p.data.target, p.data.t);
  });
  // 迷你图同样支持：悬停节点冻结，移出恢复
  miniChart.on("mouseover", p => {
    if (p.dataType !== "node") return;
    const pos = capturePositions(miniChart);
    if (!pos) return;
    const s = JSON.parse(JSON.stringify(miniChart.getOption().series[0]));
    s.layout = "none";
    s.data.forEach(d => {
      const p2 = pos[d.id];
      if (p2) { d.x = p2.x; d.y = p2.y; }
    });
    miniChart.setOption({ series: [s] });
  });
  miniChart.on("globalout", () => {
    if (!miniChart) return;
    const pos = capturePositions(miniChart);
    const s = JSON.parse(JSON.stringify(miniChart.getOption().series[0]));
    s.layout = "force";
    s.force = { repulsion: 420, edgeLength: 110, gravity: .12 };
    if (pos) s.data.forEach(d => {
      const p2 = pos[d.id];
      if (p2) { d.x = p2.x; d.y = p2.y; }
    });
    miniChart.setOption({ series: [s] });
  });
}

/* ---------- 图谱节点坐标读取 ---------- */
function capturePositions(chart) {
  try {
    const seriesModel = chart.getModel().getSeriesByIndex(0);
    const graph = seriesModel.getGraph();
    const pos = {};
    graph.eachNode(node => {
      const layout = node.getLayout();
      if (layout && node.id) pos[node.id] = { x: layout[0], y: layout[1] };
    });
    return Object.keys(pos).length ? pos : null;
  } catch (e) {
    return null;
  }
}

/* ---------- 悬停钉住：悬停哪个点，只有那个点停止飘动 ---------- */
let pinnedIds = null;   // 当前被钉住的节点 id 数组

/* 钉住机制（绝不调用 setOption，模拟不重启、视图不动）：
   layout.fixed 减弱力推动 + rAF 每帧回写锚定坐标，彻底清零漂移 */
let pinAnchor = null;
let pinRafId = null;

let pinIntervalId = null;

function writePinAnchor() {
  if (!pinnedIds || !mainChart || !pinAnchor) return;
  try {
    const g = mainChart.getModel().getSeriesByIndex(0).getGraph();
    if (!g) return;
    pinnedIds.forEach(id => {
      const a = pinAnchor[id];
      const n = g.nodes.find(nn => nn.id === id);
      if (a && n) {
        const l = n.getLayout();
        if (l) { l[0] = a.x; l[1] = a.y; }
      }
    });
  } catch (e) { /* 忽略 */ }
}

function stopPinLock() {
  if (pinRafId != null) { cancelAnimationFrame(pinRafId); pinRafId = null; }
  if (pinIntervalId != null) { clearInterval(pinIntervalId); pinIntervalId = null; }
}

function startPinLock() {
  stopPinLock();
  // 双保险：rAF + 8ms 间隔，确保在渲染前覆盖力导向写入的坐标
  pinIntervalId = setInterval(writePinAnchor, 8);
  const tick = () => {
    if (!pinnedIds || !mainChart) { pinRafId = null; return; }
    try {
      const g = mainChart.getModel().getSeriesByIndex(0).getGraph();
      if (g && pinAnchor) {
        pinnedIds.forEach(id => {
          const a = pinAnchor[id];
          const n = g.nodes.find(nn => nn.id === id);
          if (a && n) {
            const l = n.getLayout();
            if (l) { l[0] = a.x; l[1] = a.y; }
          }
        });
      }
    } catch (e) { /* 图表切换瞬间忽略 */ }
    pinRafId = requestAnimationFrame(tick);
  };
  pinRafId = requestAnimationFrame(tick);
}

function applyPin(ids) {
  if (!mainChart) return;
  const pinSet = new Set(ids || []);
  const anchor = {};
  try {
    const g = mainChart.getModel().getSeriesByIndex(0).getGraph();
    if (!g) return;
    g.eachNode(n => {
      const layout = n.getLayout();
      if (!layout) return;
      layout.fixed = pinSet.has(n.id);
      if (pinSet.has(n.id)) anchor[n.id] = { x: layout[0], y: layout[1] };
    });
  } catch (e) { /* 图表未就绪时忽略 */ }
  pinnedIds = ids && ids.length ? ids : null;
  pinAnchor = pinnedIds ? anchor : null;
  if (pinnedIds) startPinLock(); else stopPinLock();
}

function pinFromEvent(params) {
  let ids = null;
  if (params.dataType === "node") {
    ids = [params.data.id];
  } else if (params.dataType === "edge") {
    ids = [params.data.source, params.data.target];
  }
  if (!ids) return;
  const key = ids.slice().sort().join("|");
  const curKey = pinnedIds ? pinnedIds.slice().sort().join("|") : "";
  if (key === curKey) return;
  applyPin(ids);
}

function unpinAll() {
  if (!mainChart || !pinnedIds) return;
  applyPin(null);
}

/* ---------- 人物关系主图谱 ---------- */
let mainChart = null;
const factionOff = {};

function renderGraphLegend() {
  const box = document.getElementById("graph-legend");
  box.innerHTML = Object.keys(FACTIONS).map(k => {
    const f = FACTIONS[k];
    return `<button data-f="${k}" class="${factionOff[k] ? "off" : ""}">
      <span class="dot" style="background:${f.color}"></span>${f.name}（${PEOPLE_LIST.filter(p => p.faction === k).length}）</button>`;
  }).join("");
  box.querySelectorAll("button").forEach(btn => {
    btn.onclick = () => {
      const k = btn.dataset.f;
      factionOff[k] = !factionOff[k];
      renderGraphLegend();
      applyGraphFilter();
    };
  });
}

function buildGraphOption(showAllLabels) {
  const showEdgeLabels = document.getElementById("toggle-edge-labels").checked;
  const z = labelZoom;
  const nodes = PEOPLE_LIST.filter(p => !factionOff[p.faction]).map(p => {
    const f = FACTIONS[p.faction];
    const deg = DEGREE[p.id] || 0;
    return {
      id: p.id, name: p.name,
      symbolSize: Math.min(16 + deg * 2.6, 44),
      itemStyle: {
        color: f.color,
        borderColor: cssVar("--graph-node-border") || "rgba(0,0,0,.35)",
        borderWidth: .5
      },
      label: {
        show: showAllLabels || deg >= 6
      }
    };
  });
  const visible = new Set(nodes.map(n => n.id));
  // 共点边扇形散开：同一节点发出的多条连线给交替正负曲率，避免重叠
  const adjRank = {};
  const rankOf = (from, to) => {
    if (!adjRank[from]) {
      const m = {};
      (ADJ[from] || []).forEach((e, i) => { m[e.to] = i; });
      adjRank[from] = m;
    }
    return adjRank[from][to] || 0;
  };
  const links = RELATIONS.filter(r => visible.has(r.a) && visible.has(r.b)).map(r => {
    const ra = rankOf(r.a, r.b);
    const rb = rankOf(r.b, r.a);
    const sign = (ra + rb) % 2 === 0 ? 1 : -1;
    const mag = Math.min(.04 + .018 * Math.min(ra, rb), .22);
    return {
      source: r.a, target: r.b,
      lineStyle: {
        color: cssVar("--graph-edge") || "rgba(255,255,255,.16)",
        width: 1.4, curveness: sign * mag
      },
      t: r.t
    };
  });
  return {
    tooltip: {
      backgroundColor: cssVar("--panel-2") || "rgba(18,21,30,.94)",
      borderColor: "rgba(211,169,79,.5)",
      textStyle: { color: cssVar("--ink") || "#e9e4d6", fontFamily: "serif" },
      confine: true,
      formatter(p) {
        if (p.dataType === "edge") return `<b>${esc(PERSON_MAP[p.data.source].name)}</b> — ${esc(p.data.t)} — <b>${esc(PERSON_MAP[p.data.target].name)}</b>`;
        const person = PERSON_MAP[p.data.id];
        return `<b style="font-size:15px">${esc(person.name)}</b><br>
          <span style="color:#d3a94f">${esc(person.life)} · ${esc(FACTIONS[person.faction].name)}</span><br>
          <span style="color:#9aa2b1">${esc(person.title)}</span><br>
          <span style="color:#7d8593">点击查看人物详情</span>`;
      }
    },
    series: [{
      type: "graph",
      layout: "force",
      roam: true,
      force: {
        repulsion: nodes.length > 300 ? 85 : (nodes.length > 150 ? 150 : 300),
        edgeLength: nodes.length > 300 ? 38 : (nodes.length > 150 ? 52 : 80),
        gravity: .08, friction: .82
      },
      data: nodes, links,
      scaleLimit: { min: .4, max: 4 },
      labelLayout: { hideOverlap: true },
      // 节点标签：series 级配置，字号随缩放同步（见 onGraphRoam）
      label: {
        position: "bottom", distance: 4,
        color: cssVar("--ink-strong") || "#f2ead4",
        fontSize: Math.round(11.5 * z), fontWeight: 600, fontFamily: "serif",
        textBorderColor: cssVar("--graph-node-halo") || "rgba(16,19,25,.85)",
        textBorderWidth: 2.5,
        formatter: "{b}"
      },
      // 关系线文字：默认关闭（悬停人物时邻接线文字经 emphasis 始终显示），开关打开后全部显示。
      // rotate:0 必须显式设置——ECharts 默认把边标签沿线的角度旋转，细线上斜漂的文字看起来像乱飞；
      // formatter 不可返回空串——空文字仍会渲染背景药丸
      edgeLabel: {
        show: showEdgeLabels && labelZoom >= EDGE_LABEL_MIN_Z,
        rotate: 0,
        formatter: p => p.data.t,
        fontSize: Math.round(12.5 * z), fontWeight: 700, fontFamily: "serif",
        color: cssVar("--edge-label-fg") || "#ffe6bd",
        backgroundColor: cssVar("--edge-label-bg") || "rgba(18,14,8,.85)",
        borderColor: "rgba(211,169,79,.8)", borderWidth: 1.5,
        borderRadius: 7, padding: [3, 9]
      },
      emphasis: {
        focus: "adjacency",
        scale: 1.6,
        itemStyle: {
          borderColor: "#d3a94f", borderWidth: 3,
          shadowBlur: 22, shadowColor: "rgba(211,169,79,.85)"
        },
        label: {
          show: true, position: "bottom", distance: 6,
          fontSize: Math.round(15 * z), fontWeight: 700, fontFamily: "serif",
          color: "#fff6df",
          textBorderColor: cssVar("--graph-node-halo") || "rgba(16,19,25,.9)",
          textBorderWidth: 3
        },
        edgeLabel: {
          show: true, rotate: 0, fontSize: Math.round(15 * z), fontWeight: 700, fontFamily: "serif",
          color: "#ffffff",
          backgroundColor: "rgba(178,45,34,.95)",
          borderColor: "#e8c67a", borderWidth: 2,
          borderRadius: 8, padding: [5, 12],
          formatter: p => `${PERSON_MAP[p.data.source].name} — ${p.data.t} — ${PERSON_MAP[p.data.target].name}`
        },
        lineStyle: { color: "#d3a94f", width: 3 }
      },
      blur: {
        itemStyle: { opacity: .12 },
        label: { opacity: .1 },
        lineStyle: { opacity: .08 }
      }
    }]
  };
}

/* 缩放时同步标签字号：监听 graphRoam，读取视图缩放，series 级合并更新
   （不触碰 data/links，力导向模拟不受影响） */
let labelZoom = 1;
let labelZoomTimer = null;
/* 低于该缩放倍率时隐藏关系线文字（总览图线长且稀，标签会漂浮在空白处） */
const EDGE_LABEL_MIN_Z = 1.0;

/* 读取当前实际缩放并同步字号与关系文字显示（初始化/筛选重建后也需调用，
   因为自动缩放不触发 graphRoam 事件） */
function syncGraphZoom(force) {
  if (!mainChart) return;
  try {
    const cs = mainChart.getModel().getSeriesByIndex(0).coordinateSystem;
    const z = Math.min(4, Math.max(.4, cs.scaleX || 1));
    if (!force && Math.abs(z - labelZoom) < .04) return;
    labelZoom = z;
    const edgeOn = document.getElementById("toggle-edge-labels").checked && z >= EDGE_LABEL_MIN_Z;
    mainChart.setOption({ series: [{
      label: { fontSize: Math.round(11.5 * z) },
      edgeLabel: { show: edgeOn, fontSize: Math.round(12.5 * z) },
      emphasis: {
        label: { fontSize: Math.round(15 * z) },
        edgeLabel: { fontSize: Math.round(15 * z) }
      }
    }] });
  } catch (e) { /* 忽略 */ }
}

function onGraphRoam() {
  if (!mainChart) return;
  clearTimeout(labelZoomTimer);
  labelZoomTimer = setTimeout(() => syncGraphZoom(false), 120);
}

function initGraph() {
  const el = document.getElementById("graph");
  if (typeof echarts === "undefined") {
    el.innerHTML = `<div class="grid-empty">图表库加载失败，请检查 lib/echarts.min.js</div>`;
    return;
  }
  mainChart = echarts.init(el);
  mainChart.setOption(buildGraphOption(false));
  // 自动缩放不触发 graphRoam：布局稳定后主动同步实际缩放（两次以防中途收敛）
  setTimeout(() => syncGraphZoom(true), 700);
  setTimeout(() => syncGraphZoom(true), 2200);
  mainChart.on("click", p => {
    if (p.dataType === "node") openPerson(p.data.id);
    else if (p.dataType === "edge") openRelation(p.data.source, p.data.target, p.data.t);
  });
  // 缩放/平移时同步标签字号（series 级合并更新，不影响力导向模拟）
  mainChart.on("graphRoam", onGraphRoam);
  // 悬停到人物节点：该人物原地定住；悬停到关系连线：连线两端人物定住；其余继续飘动
  mainChart.on("mouseover", pinFromEvent);
  mainChart.on("globalout", unpinAll);
  document.getElementById("toggle-edge-labels").onchange = () => {
    if (document.getElementById("toggle-edge-labels").checked) {
      toastMsg("已显示关系线文字（自动避让重叠）；悬停人物可高亮其全部关系");
    }
    applyGraphFilter();
  };
  const legendToggle = document.getElementById("legend-toggle");
  if (legendToggle) {
    legendToggle.onclick = () => {
      const lg = document.getElementById("graph-legend");
      const open = lg.classList.toggle("open");
      legendToggle.textContent = open ? "阵营筛选 ▴" : "阵营筛选 ▾";
    };
  }
  window.addEventListener("resize", () => mainChart && mainChart.resize());
}

function applyGraphFilter() {
  if (!mainChart) return;
  mainChart.setOption(buildGraphOption(document.getElementById("toggle-labels").checked));
  // 重建后视图回到自适应缩放，主动同步（延迟等布局收敛）
  setTimeout(() => syncGraphZoom(true), 600);
}

document.getElementById("toggle-labels").onchange = () => applyGraphFilter();

/* ---------- 返回顶部 ---------- */
const backTopBtn = document.getElementById("back-top");
window.addEventListener("scroll", () => {
  backTopBtn.classList.toggle("show", window.scrollY > 600);
});
backTopBtn.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });

/* ---------- 右侧浮动导航 ---------- */
function jumpToEra(pk) {
  switchTab("timeline-section", false);
  const key = String(pk);
  openEras.add(key);
  const el = document.querySelector(`#timeline .era[data-era="${key}"]`);
  if (!el) { renderTimeline(); }
  const target = document.querySelector(`#timeline .era[data-era="${key}"]`);
  if (target) {
    target.classList.add("open");
    syncToggleAllBtn();
    setTimeout(() => target.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }
}
(function initSideMenu() {
  const box = document.getElementById("side-periods");
  box.innerHTML = Object.keys(PERIODS).map(k =>
    `<button class="side-era" data-era="${k}"><i>${k}</i>${PERIODS[k].name}</button>`).join("");
  box.querySelectorAll(".side-era").forEach(btn => {
    btn.onclick = () => jumpToEra(btn.dataset.era);
  });
})();

/* ---------- 版本更新检查（对比 GitHub 上的 version.json） ---------- */
const CURRENT_VERSION = { version: "2.19.0", build: 1789526612 };

function toastMsg(text, ms) {
  let t = document.getElementById("global-toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "global-toast";
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = text;
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), ms || 2600);
}

async function checkUpdate(manual) {
  const btn = document.getElementById("update-btn");
  if (!btn) return;
  if (manual) btn.textContent = "⏳ 正在检查…";
  try {
    const res = await fetch("version.json?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error(res.status);
    const info = await res.json();
    if (info.build > CURRENT_VERSION.build) {
      btn.classList.add("has-update");
      btn.innerHTML = "🆕 发现新版本 v" + esc(info.version) + " · 点击更新";
      btn.onclick = () => {
        btn.textContent = "⏳ 正在更新…";
        location.replace(location.pathname + "?v=" + info.build + "&t=" + Date.now() + location.hash);
      };
      if (manual) toastMsg("发现新版本 v" + info.version + "，点击按钮即可更新");
    } else {
      if (manual) {
        btn.textContent = "🔄 检查更新";
        toastMsg("已是最新版本（v" + CURRENT_VERSION.version + "）");
      }
    }
  } catch (e) {
    if (manual) {
      btn.textContent = "🔄 检查更新";
      toastMsg("检查更新失败：无法获取 version.json");
    }
  }
}

/* ---------- 事件委托：卡片 / 弹窗内跳转 ---------- */
document.addEventListener("click", e => {
  const term = e.target.closest(".term");
  if (term) { showTermPop(term); return; }
  const evCard = e.target.closest("[data-open-event]");
  if (evCard) { openEvent(evCard.dataset.openEvent); return; }
  const pCard = e.target.closest("[data-open-person]");
  if (pCard) { openPerson(pCard.dataset.openPerson); return; }
});

/* ---------- 新手指南 ---------- */
document.getElementById("guide-btn").onclick = () => {
  modalBody.innerHTML = `
    <h3 class="m-title">📖 第一次看？三分钟上手</h3>
    <div class="beginner-note">本站收录中国五千年历史中的 <b>${EVENTS.length}</b> 个大事件、<b>${PEOPLE_LIST.length}</b> 位人物、<b>${RELATIONS.length}</b> 组人物关系。下面教你怎么玩。</div>
    <h4 class="m-h4">① 大事年表怎么看</h4>
    <p class="m-desc">页面按<b>时间顺序</b>把历史分成16个时期（传说时代 → … → 当代中国）。每个时期下是当年发生的大事卡片，<b>点任意卡片</b>就能看到：这件事的<b>大白话速览</b>、来龙去脉、交战双方的<b>兵力对比</b>、结局影响、相关人物。</p>
    <h4 class="m-h4">② 看不懂的词怎么办</h4>
    <p class="m-desc">正文里带<span class="term-demo">虚线下划线</span>的词（比如${glossarize(esc("科举、禅让、藩镇"))}）都是历史术语，<b>点一下</b>就会弹出大白话解释。</p>
    <h4 class="m-h4">③ 关系图谱怎么玩</h4>
    <p class="m-desc">切换到"关系图谱"页：每个圆点是一个人（颜色代表阵营，越大越有分量）。<b>鼠标放到一个人身上</b>，他本人定住、连线亮起并显示和邻居的关系；<b>点一下人物</b>看生平；<b>点一下连线</b>看两人共同经历的事件（比如两人打过的仗）。滚轮缩放、拖拽平移。</p>
    <h4 class="m-h4">④ 人物志怎么用</h4>
    <p class="m-desc">按阵营浏览全部人物，<b>点卡片</b>看详细生平：他的一生按年份排成<b>年谱</b>（哪年出生、哪年考上功名、哪年打了什么仗），下面还有以他为中心的关系小图。</p>
    <h4 class="m-h4">⑤ 顶部搜索框</h4>
    <p class="m-desc">输入任何关键词（人名、战役名、朝代）即时过滤事件和人物。</p>`;
  openModal();
  modalBody.scrollTop = 0;
};

/* ---------- 启动 ---------- */
applyTheme(currentTheme(), false);
renderCatFilters();
renderTimeline();
renderFactionFilters();
renderPeopleGrid();
renderGraphLegend();
document.getElementById("update-btn").onclick = () => checkUpdate(true);
checkUpdate(false);   // 静默检查一次，有新版本时按钮自动亮起

/* 动态加载维基扩展阅读数据（由 scripts/fetch-wiki.py 生成；不存在则静默跳过） */
(function loadWikiBios() {
  const s = document.createElement("script");
  s.src = "js/wiki-bios.js?v=" + CURRENT_VERSION.build;
  s.onerror = () => s.remove();
  document.head.appendChild(s);
})();

(function initTabFromHash() {
  const h = (location.hash || "").replace("#", "");
  if (TABS.indexOf(h) !== -1) switchTab(h, false);
})();


/* ---------- 疆域变迁地图 ---------- */
var periodMapChart = null;
var mapCurrentPk = 4;

const MAP_DIM = () => (document.body.classList.contains("light") ? "#e8e2d2" : "#272c38");
const MAP_DIM_LINE = () => (document.body.classList.contains("light") ? "rgba(90,80,60,.35)" : "rgba(255,255,255,.08)");

function initPeriodMap() {
  const el = document.getElementById("china-map");
  if (!el || typeof echarts === "undefined") return;
  periodMapChart = echarts.init(el);
  renderMapEras();
  renderPeriodMap();
  periodMapChart.on("click", p => {
    if (p.seriesType === "effectScatter" && p.data && p.data.eid) openEvent(p.data.eid);
  });
  document.getElementById("toggle-map-battles").onchange = () => renderPeriodMap();
  document.getElementById("map-prev").onclick = () => {
    mapCurrentPk = mapCurrentPk <= 1 ? 16 : mapCurrentPk - 1;
    renderPeriodMap(); renderMapEras();
  };
  document.getElementById("map-next").onclick = () => {
    mapCurrentPk = mapCurrentPk >= 16 ? 1 : mapCurrentPk + 1;
    renderPeriodMap(); renderMapEras();
  };
}

function renderMapEras() {
  const box = document.getElementById("map-eras");
  if (!box) return;
  box.innerHTML = Object.keys(PERIODS).map(pk =>
    `<button class="map-era-btn ${String(pk) === String(mapCurrentPk) ? "active" : ""}" data-pk="${pk}" title="${esc(PERIODS[pk].sub)}">${esc(PERIODS[pk].name)}</button>`
  ).join("");
  box.querySelectorAll(".map-era-btn").forEach(b => {
    b.onclick = () => { mapCurrentPk = +b.dataset.pk; renderPeriodMap(); renderMapEras(); };
  });
  const cur = box.querySelector(".map-era-btn.active");
  if (cur) cur.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
}

function renderPeriodMap() {
  if (!periodMapChart) return;
  const cfg = PERIOD_MAPS[mapCurrentPk];
  const period = PERIODS[mapCurrentPk];
  const polities = Object.assign({}, cfg.polities || {}, cfg.polities2 || {});

  const listed = cfg.areas || {};
  const geoJson = echarts.getMap("china") ? echarts.getMap("china").geoJson : null;
  const names = geoJson ? geoJson.features.map(f => f.properties.name) : [];
  const data = names.map(n => {
    const pk = listed[n];
    const pol = pk && polities[pk] ? polities[pk] : null;
    return pol
      ? { name: n, pol: pol.name,
          itemStyle: { areaColor: pol.color, borderColor: "rgba(0,0,0,.25)" },
          emphasis: { itemStyle: { areaColor: pol.color } } }
      : { name: n, pol: null,
          itemStyle: { areaColor: MAP_DIM(), borderColor: MAP_DIM_LINE() },
          emphasis: { itemStyle: { areaColor: MAP_DIM() } } };
  });

  const showBattles = document.getElementById("toggle-map-battles").checked;
  const battleEvents = typeof BATTLE_COORDS !== "undefined"
    ? EVENTS.filter(ev => ev.category === "war"
        && (ev.p || periodOf(ev)) === mapCurrentPk
        && BATTLE_COORDS[ev.id])
    : [];
  const routes = typeof PERIOD_ROUTES !== "undefined" && PERIOD_ROUTES[mapCurrentPk]
    ? PERIOD_ROUTES[mapCurrentPk] : [];

  const caps = (cfg.caps || []).map(([name, lng, lat, kind]) => ({
    name, value: [lng, lat],
    symbol: kind === 1 ? "pin" : "circle",
    symbolSize: kind === 1 ? 34 : 13,
    itemStyle: { color: kind === 1 ? "#e8c67a" : "#d3a94f", borderColor: "rgba(0,0,0,.4)", borderWidth: 1 },
    label: { show: true, position: "top", fontSize: 11.5, fontWeight: 700, fontFamily: "serif",
             color: cssVar("--ink-strong") || "#f2ead4",
             textBorderColor: cssVar("--graph-node-halo") || "rgba(16,19,25,.9)", textBorderWidth: 2.5,
             formatter: name }
  }));

  periodMapChart.setOption({
    tooltip: {
      backgroundColor: cssVar("--panel-2") || "rgba(18,21,30,.94)",
      borderColor: "rgba(211,169,79,.5)",
      textStyle: { color: cssVar("--ink") || "#e9e4d6", fontFamily: "serif", fontSize: 13 },
      confine: true,
      formatter: p => {
        if (p.seriesType === "map") return `<b>${p.name}</b>${p.data.pol ? " · " + p.data.pol : " · 时期内无有效控制"}`;
        if (p.seriesType === "effectScatter") return `<b style="color:#ff9d8a">${esc(String(p.data.year))}</b> · <b>${p.name}</b><br><span style="color:#9aa2b1">点击查看战役详情</span>`;
        if (p.seriesType === "lines") return `<b>${p.name}</b>`;
        return `<b>${p.name}</b>`;
      }
    },
    geo: {
      map: "china", roam: true, zoom: 1.12, aspectScale: .82,
      itemStyle: { borderColor: "rgba(0,0,0,.25)", borderWidth: .6 },
      label: { show: false },
      select: { disabled: true }
    },
    series: [
      { type: "map", map: "china", geoIndex: 0, data },
      { type: "scatter", coordinateSystem: "geo", data: caps,
        zlevel: 2, silent: false },
      ...(showBattles ? [{
        type: "effectScatter", coordinateSystem: "geo", zlevel: 4,
        rippleEffect: { brushType: "stroke", scale: 3.2 },
        symbolSize: 11,
        itemStyle: { color: "#e05545", shadowBlur: 8, shadowColor: "rgba(224,85,69,.8)" },
        label: { show: false },
        data: battleEvents.map(ev => ({
          name: ev.title, value: BATTLE_COORDS[ev.id], eid: ev.id, year: ev.year,
          label: { show: true, position: "right", fontSize: 11, fontWeight: 700, fontFamily: "serif",
                   color: "#ffd9c9",
                   textBorderColor: "rgba(16,19,25,.9)", textBorderWidth: 2.5,
                   formatter: ev.title.length > 12 ? ev.title.slice(0, 11) + "…" : ev.title }
        }))
      }] : []),
      ...(routes.length ? [{
        type: "lines", coordinateSystem: "geo", zlevel: 3, polyline: true, silent: true,
        lineStyle: { opacity: .8 },
        data: routes.map(r => ({ name: r.name,
          coords: r.coords,
          lineStyle: { color: r.color, width: 3, type: r.dash ? "dashed" : "solid", opacity: .75 } }))
      }] : []),
      ...(cfg.bounds && cfg.bounds.length ? [{
        type: "custom", coordinateSystem: "geo", zlevel: 3, clip: false, silent: false,
        data: cfg.bounds.map(b => ({ name: b.name, pts: b.pts, pol: b.pol, lost: b.lost })),
        renderItem: (params, api) => {
          const d = params.data;
          const pts = d.pts.map(pt => api.coord(pt));
          const polColor = d.pol && polities[d.pol] ? polities[d.pol].color : "#b0553c";
          return {
            type: "polygon",
            shape: { points: pts, smooth: .25 },
            style: d.lost
              ? { fill: "rgba(150,40,40,.18)", stroke: "#c05050", lineWidth: 1.6,
                  lineDash: [7, 5], opacity: .95 }
              : { fill: polColor, opacity: .38, stroke: polColor, lineWidth: 1.6 }
          };
        }
      }] : [])
    ]
  }, true);

  const legendHtml = Object.entries(polities).map(([k, v]) =>
    `<span class="map-leg"><i style="background:${v.color}"></i>${esc(v.name)}</span>`).join("");
  const battleHtml = battleEvents.length
    ? `<span class="map-leg"><i style="background:#e05545;border-radius:50%"></i>本时期战役 ${battleEvents.length} 场（点击标记查看详情）</span>` : "";
  const routeHtml = routes.map(r =>
    `<span class="map-leg"><i style="background:${r.color};height:4px;border-radius:2px;${r.dash ? "opacity:.85;" : ""}"></i>${esc(r.name)}</span>`).join("");
  const boundsHtml = (cfg.bounds || []).map(b =>
    `<span class="map-leg"><i style="background:${b.lost ? "rgba(150,40,40,.35)" : (polities[b.pol] ? polities[b.pol].color : "#b0553c")};opacity:.75;${b.lost ? "border:1.5px dashed #c05050;" : ""}"></i>${esc(b.name)}</span>`).join("");
  document.getElementById("map-info").innerHTML = `
    <div class="map-info-head">
      <h3>${esc(period.name)} <span class="map-years">${esc(cfg.years)}</span></h3>
      <p class="map-desc">${esc(cfg.desc)}</p>
    </div>
    <div class="map-legend">${legendHtml}${routeHtml}${boundsHtml}${battleHtml}
      ${cfg.outside ? `<span class="map-leg map-leg-out">↕ 底图之外：${esc(cfg.outside)}</span>` : ""}
    </div>`;
}

window.addEventListener("resize", () => periodMapChart && periodMapChart.resize());


/* ---------- 星空粒子背景 ---------- */
(function initStars() {
  const cv = document.getElementById("stars");
  if (!cv) return;
  const ctx = cv.getContext("2d");
  let W, H, stars = [], running = true;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function resize() {
    W = cv.width = window.innerWidth;
    H = cv.height = window.innerHeight;
    const n = Math.min(170, Math.round(W * H / 12000));
    stars = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.4 + .3,
      vx: (Math.random() - .5) * .12, vy: (Math.random() - .5) * .1,
      a: Math.random() * .6 + .15, tw: Math.random() * Math.PI * 2,
      gold: Math.random() < .3
    }));
  }
  function tick() {
    if (!running) return;
    ctx.clearRect(0, 0, W, H);
    for (const st of stars) {
      st.x += st.vx; st.y += st.vy; st.tw += .02;
      if (st.x < 0) st.x = W; if (st.x > W) st.x = 0;
      if (st.y < 0) st.y = H; if (st.y > H) st.y = 0;
      const alpha = st.a * (0.6 + 0.4 * Math.sin(st.tw));
      ctx.beginPath();
      ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
      ctx.fillStyle = st.gold ? `rgba(220,180,105,${alpha})` : `rgba(200,210,235,${alpha * .8})`;
      ctx.fill();
    }
    requestAnimationFrame(tick);
  }
  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", () => {
    running = !document.hidden && !reduce;
    if (running) requestAnimationFrame(tick);
  });
  resize();
  if (!reduce) requestAnimationFrame(tick);
  else { ctx.clearRect(0, 0, W, H); for (const st of stars) { ctx.beginPath(); ctx.arc(st.x, st.y, st.r, 0, Math.PI*2); ctx.fillStyle = st.gold ? "rgba(220,180,105,.5)" : "rgba(200,210,235,.35)"; ctx.fill(); } }
})();

/* ---------- 开场主页 ---------- */
(function initIntro() {
  const intro = document.getElementById("intro");
  if (!intro) return;

  // 朝代流转条（两份拼接实现无缝滚动）
  const dyn = "夏 商 西周 东周 春秋 战国 秦 西汉 东汉 三国 西晋 东晋 南北朝 隋 唐 五代 宋 辽金 元 明 清 民国 共和国".split(" ");
  const track = document.getElementById("intro-dynasties");
  const half = dyn.map(d => `<b>${d}</b>`).join("") + dyn.map(d => `<b>${d}</b>`).join("");
  track.innerHTML = half;

  // 名言打字机
  const quote = "以铜为镜，可以正衣冠；以史为镜，可以知兴替。";
  const qEl = document.getElementById("intro-quote");
  let qi = 0;
  const timer = setInterval(() => {
    qEl.textContent = quote.slice(0, ++qi);
    if (qi >= quote.length) clearInterval(timer);
  }, 90);

  // 数据计数
  const counters = [
    ["stat-p", Object.keys(PEOPLE).length],
    ["stat-e", EVENTS.length],
    ["stat-r", RELATIONS.length]
  ];
  counters.forEach(([id, target]) => {
    const el = document.getElementById(id);
    const t0 = performance.now(), dur = 1400;
    (function step(t) {
      const k = Math.min(1, (t - t0) / dur);
      el.textContent = Math.round(target * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(step);
    })(t0);
  });

  function enter() {
    if (intro.classList.contains("out")) return;
    clearInterval(timer);
    intro.classList.add("out");
    setTimeout(() => intro.remove(), 950);
    try { document.getElementById("search-input") && document.getElementById("search-input").blur(); } catch (e) {}
  }
  document.getElementById("intro-enter").onclick = enter;
  window.addEventListener("keydown", e => {
    if (!intro.classList.contains("out") && (e.key === "Enter" || e.key === " ")) enter();
  });
})();
